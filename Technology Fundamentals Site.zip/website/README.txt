This is a small simple website made by George Bursuc and Thomas Cummins for our Technology Fundamentals module. The website goes through all of the components of a PC and what it can do. You start at home.html and have two other pages you can navigate to by clicking the pictures where indicated.

Home page and compenents page made by: George Bursuc
Operating Systems page made by: Thomas Cummins